export default () => {
  return <div className="tablex-nodata-msg">暂无数据</div>;
};
